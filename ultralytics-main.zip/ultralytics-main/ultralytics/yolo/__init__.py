# Ultralytics YOLO 🚀, AGPL-3.0 license

from . import v8

__all__ = 'v8',  # tuple or list
